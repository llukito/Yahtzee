
/*
 * File: Yahtzee.java
 * ------------------
 * This program will eventually play the Yahtzee game.
 */

import java.util.*;

import acm.io.*;
import acm.program.*;
import acm.util.*;

public class Yahtzee extends GraphicsProgram implements YahtzeeConstants {

	public static void main(String[] args) {
		new Yahtzee().start(args);
	}

	public void run() {
		IODialog dialog = getDialog();
		nPlayers = dialog.readInt("Enter number of players");
		checkNumOfPlayers(dialog);
		playerNames = new String[nPlayers];
		for (int i = 1; i <= nPlayers; i++) {
			playerNames[i - 1] = dialog.readLine("Enter name for player " + i);
		}
		display = new YahtzeeDisplay(getGCanvas(), playerNames);
		// initializing matrixes
		usedCategories = new boolean[nPlayers][N_CATEGORIES];
		totalScores = new int[nPlayers][N_CATEGORIES];
		playGame();
	}

	/*
	 * This method is essential so our game does not crash when wrong number of
	 * players is entered( only (1-4) range is acceptable). So we should monitor
	 * and check number of Players
	 */
	private void checkNumOfPlayers(IODialog dialog) {
		while (nPlayers > MAX_PLAYERS || nPlayers < MIN_PLAYERS) {
			if (nPlayers < MIN_PLAYERS) {
				dialog.println("At least 1 player should play");
			} else if (nPlayers > MAX_PLAYERS) {
				dialog.println("At most 4 players can play ");
			}
			nPlayers = dialog.readInt("Enter number of players");
		}
	}

	private void playGame() {
		for (int r = 0; r < TOTAL_ROUNDS; r++) { // every player rolls dice in every round
			for (int player = 1; player <= nPlayers; player++) {
				int[] dice = new int[N_DICE]; // array of dice values(5 in total)
				int playerIndex = player - 1;
				display.printMessage(playerNames[playerIndex] + "'s turn. Click \"Roll Dice\" button to roll the dice");
				display.waitForPlayerToClickRoll(player);
				processOfRollingDice(dice);
				display.printMessage("Select a category for this roll.");
				int category = display.waitForPlayerToSelectCategory();
				category = checkCategoryValidity(playerIndex, category);
				checkCategorySatisfaction(playerIndex, category, dice);
				display.updateScorecard(category, player, score); // update category score
			}
		}
		endOfGame();
	}

	private void processOfRollingDice(int[] dice) {
		generateRandomDiceValues(dice); // first roll of dice
		display.displayDice(dice);
		for (int i = 0; i < 2; i++) { // player can re-roll dice for 2 times
			display.printMessage("Select the dice you wish to re-roll and click \"Roll Again\" ");
			rollAgain(dice);
			display.displayDice(dice);
		}
	}

	private void generateRandomDiceValues(int[] dice) {
		for (int i = 0; i < dice.length; i++) { // all 5 dice receive values
			dice[i] = (rgen.nextInt(1, 6));
		}
	}

	/*
	 * Only selected dice will be rolled again
	 */
	private void rollAgain(int[] dice) {
		display.waitForPlayerToSelectDice();
		for (int n = 0; n < dice.length; n++) {
			if (display.isDieSelected(n)) {
				dice[n] = rgen.nextInt(1, 6);
			}
		}
	}

	/*
	 * This method checks validity of chosen category. It if was previously
	 * used, player receives specific message, if not, we remember it in boolean
	 * array ( if already used, it is true, if not it is false(as a default))
	 */
	private int checkCategoryValidity(int playerIndex, int category) {
		while (true) {
			if (usedCategories[playerIndex][category]) { // if true, it was previously used
				IODialog errorDialog = getDialog();
				errorDialog.println("This category has already been used. Choose a different one.");
				category = display.waitForPlayerToSelectCategory();
			} else {
				usedCategories[playerIndex][category] = true; // note it as used
				break;
			}
		}
		return category;
	}

	/*
	 * This method checks if dice values satisfy chosen category. It sets score
	 * as 0, if category is not satisfied, score will remain 0. At the end, we
	 * of course remember score player got and display it on scoreSheet
	 */
	private void checkCategorySatisfaction(int playerIndex, int category, int[] dice) {
		score = 0; // score resets
		switch (category) {
		case ONES:
			checkOneNumber(ONES, dice);
			break;
		case TWOS:
			checkOneNumber(TWOS, dice);
			break;
		case THREES:
			checkOneNumber(THREES, dice);
			break;
		case FOURS:
			checkOneNumber(FOURS, dice);
			break;
		case FIVES:
			checkOneNumber(FIVES, dice);
			break;
		case SIXES:
			checkOneNumber(SIXES, dice);
			break;
		case THREE_OF_A_KIND:
			checkNumOfAKind(3, dice);
			break;
		case FOUR_OF_A_KIND:
			checkNumOfAKind(4, dice);
			break;
		case FULL_HOUSE:
			checkFullHouse(dice);
			break;
		case SMALL_STRAIGHT:
			checkStraights(4, dice, 30);
			break;
		case LARGE_STRAIGHT:
			checkStraights(5, dice, 40);
			break;
		case YAHTZEE:
			checkYahtzee(dice);
			break;
		case CHANCE:
			getScore(dice);
			break;
		default:
			throw new ErrorException("Illegal category");
		}
		totalScores[playerIndex][category - 1] = score; // note it in matrix
		//update total points
		display.updateScorecard(TOTAL, playerIndex + 1, upperScore(playerIndex) + lowerScore(playerIndex));
	}

	private void checkOneNumber(int categoryValue, int[] dice) {
		for (int diceValue : dice) {
			if (diceValue == categoryValue) {
				score += categoryValue;
			}
		}
	}

	private void checkNumOfAKind(int num, int[] dice) {
		HashMap<Integer, Integer> frequencyMap = new HashMap<>();
		// counting frequency of dice values
		for (int diceValue : dice) {
			frequencyMap.put(diceValue, frequencyMap.getOrDefault(diceValue, 0) + 1);
			if (frequencyMap.get(diceValue) >= num) {
				getScore(dice);
				break;
			}
		}
	}

	/*
	 * stores frequencies of values of dice
	 */
	private void checkFullHouse(int[] dice) {
		HashMap<Integer, Integer> frequencyMap = new HashMap<>();
		// counting frequency of dice values
		for (int diceValue : dice) {
			// this line does two things : adds new if already exists or increases by one
			frequencyMap.put(diceValue, frequencyMap.getOrDefault(diceValue, 0) + 1);
		}
		checkFrequencySatisfaction(frequencyMap);
	}

	/*
	 * checks whether there are 2 and 3 frequencies among all five frequencies
	 * or not
	 */
	private void checkFrequencySatisfaction(HashMap<Integer, Integer> list) {
		boolean frequencyOfThree = false;
		boolean frequencyOfTwo = false;
		for (int frequency : list.values()) {
			if (frequency == 3) {
				frequencyOfThree = true;
			} else if (frequency == 2) {
				frequencyOfTwo = true;
			}
		}
		if (frequencyOfThree && frequencyOfTwo) {
			score = 25;
		}
	}

	private void checkStraights(int straight, int[] dice, int numOfScore) {
		if (straight == 5) {
			if (diceHasLargeStraight(dice)) {
				score = numOfScore;
			}
		} else if (straight == 4) {
			if (diceHasSmallStraight(dice)) {
				score = numOfScore;
			}
		}
	}

	private boolean diceHasLargeStraight(int[] dice) {
		int[][] allPossibleLargeStraights = new int[4][dice.length];
		fillWithLargeStraights(allPossibleLargeStraights);
		for (int[] largeStraight : allPossibleLargeStraights) {
			if (Arrays.equals(dice, largeStraight)) {
				return true;
			}
		}
		return false;
	}

	/*
	 * apparently there are 4 ways you can get Large straight. Sequence matters,
	 * but it can be reserved (1,2,3,4,5 -> 5,4,3,2,1) both valid
	 */
	private void fillWithLargeStraights(int[][] allPossibleLargeStraights) {
		allPossibleLargeStraights[0] = new int[] { 1, 2, 3, 4, 5 };
		allPossibleLargeStraights[1] = new int[] { 2, 3, 4, 5, 6 };
		allPossibleLargeStraights[2] = new int[] { 5, 4, 3, 2, 1 };
		allPossibleLargeStraights[3] = new int[] { 6, 5, 4, 3, 2 };
	}

	/*
	 * we should check 4 values in 5 . So there are two ways : 1) first four
	 * values and 2) last four values
	 */
	private boolean diceHasSmallStraight(int[] dice) {
		int[][] allPossibleSmallStraights = new int[6][dice.length - 1];
		fillWithSmallStraights(allPossibleSmallStraights);
		for (int[] smallStraight : allPossibleSmallStraights) {
			if (Arrays.equals(Arrays.copyOfRange(dice, 0, dice.length - 1), smallStraight) || // first 4 values
					Arrays.equals(Arrays.copyOfRange(dice, 1, dice.length), smallStraight)) { // last 4 values
																						
				return true;
			}
		}
		return false;
	}

	/*
	 * apparently there are 6 ways you can get small straight. Sequence matters,
	 * but it can be reserved (1,2,3,4 -> 4,3,2,1) both valid
	 */
	private void fillWithSmallStraights(int[][] allPossibleSmallStraights) {
		allPossibleSmallStraights[0] = new int[] { 1, 2, 3, 4 };
		allPossibleSmallStraights[1] = new int[] { 2, 3, 4, 5 };
		allPossibleSmallStraights[2] = new int[] { 3, 4, 5, 6 };
		allPossibleSmallStraights[3] = new int[] { 4, 3, 2, 1 };
		allPossibleSmallStraights[4] = new int[] { 5, 4, 3, 2 };
		allPossibleSmallStraights[5] = new int[] { 6, 5, 4, 3 };
	}

	private void checkYahtzee(int[] dice) {
		int value = dice[0];
		for (int n : dice) {
			if (n != value) {
				return; // returns with 0 score
			}
		}
		score = 50;
	}

	/*
	 * Simply adds all dice Values to each other
	 */
	private void getScore(int[] dice) {
		for (int diceValue : dice) {
			score += diceValue;
		}
	}

	/*
	 * Counts score in first 6 categories
	 */
	private int upperScore(int row) {
		int num = 0;
		for (int c = ONES; c <= SIXES; c++) {
			num += totalScores[row][c - 1];
		}
		return num;
	}

	/*
	 * Counts scores in remaining(below) categories
	 */
	private int lowerScore(int row) {
		int num = 0;
		for (int c = THREE_OF_A_KIND; c <= CHANCE; c++) {
			num += totalScores[row][c - 1];
		}
		return num;
	}

	private void endOfGame() {
		int maximumPoints = 0;
		HashMap<String, Integer> winnersMap = new HashMap<String, Integer>();
		maximumPoints = checkBonuseAndUpdateScore(maximumPoints, winnersMap);
		printWinners(maximumPoints, winnersMap);
	}

	/*
	 * This method fills remaining categories of scoresheet and calculates the
	 * highest score, which is then returned into finalScore method
	 */
	private int checkBonuseAndUpdateScore(int max, HashMap<String, Integer> map) {
		// will iterate through all players
		for (int player = 1; player <= nPlayers; player++) {												
			int playerIndex = player - 1;
			int upperPoints = upperScore(playerIndex);
			display.updateScorecard(UPPER_SCORE, player, upperPoints);
			int lowerPoints = lowerScore(playerIndex);
			display.updateScorecard(LOWER_SCORE, player, lowerPoints);
			int totalPoints = upperPoints + lowerPoints;
			totalPoints = checkForUpperPointsBonus(upperPoints, totalPoints, player);
			if (totalPoints >= max) {
				max = totalPoints; // renews max
				// remembers which players changed maximum
				map.put(playerNames[playerIndex], max);
			}
		}
		return max;
	}

	private int checkForUpperPointsBonus(int upperPoints, int totalPoints, int player) {
		if (upperPoints >= 63) { // if bonus is satisfied
			totalPoints += 35; // player gets extra 35 points
			display.updateScorecard(UPPER_BONUS, player, 35);
			display.updateScorecard(TOTAL, player, totalPoints); // we have new total															
		} else { // total remains same
			display.updateScorecard(UPPER_BONUS, player, 0);
		}
		return totalPoints; // let's return renewed totalPoints
	}

	/*
	 * This method prints winners(if there are more than one), or just one
	 * winner
	 */
	private void printWinners(int max, HashMap<String, Integer> winners) {
		String str = "";
		int numberOfWinners = 1; // as a default, we have one winner
		for (String player : winners.keySet()) {
			if (winners.get(player) == max) { // whoever changed max last is a winner
				if (numberOfWinners > 1) { // if there are more than one winners
					str += "and ";
				}
				str += player + " ";
				numberOfWinners++;
			}
		}
		display.printMessage("Congratulations, " + str + ", you're the winner with a total score of " + max + " !");
	}

	/* Private instance variables */
	private int nPlayers;
	private String[] playerNames;
	private YahtzeeDisplay display;
	private int score = 0;
	private boolean[][] usedCategories;
	private int[][] totalScores;
	private RandomGenerator rgen = new RandomGenerator();
}
